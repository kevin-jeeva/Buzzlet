/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Processing;

import BusinessBeans.User;
import BusinessBeans.UserBL;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kevin jeeva
 */
@WebServlet(name = "signup_proc", urlPatterns = {"/signup_proc"})
public class signup_proc extends HttpServlet {
@EJB User u;
@EJB UserBL UBL;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
          
           String user = request.getParameter("username");
           String password = request.getParameter("password");
           String email = request.getParameter("Email");
           
           u.setPassword(password);
           u.setUserName(user);
           u.setEmail(email);
           
         
              boolean userExist = UBL.UserExists(u.getUserName());
              if(userExist == true)
              {
                  boolean userResult = UBL.InsertUser(u.getUserName(), u.getPassword(), u.getEmail());
                  if(userResult == true)
                  {
                       String message = "You have created account successfully";
                       request.getSession().setAttribute("message", message);
                       getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
                  }
                  else
                  {
                        String message = "Error inserting user";
                        request.getSession().setAttribute("alert", message);
                        getServletContext().getRequestDispatcher("/signup.jsp").forward(request, response);
                  }
                          
              }
              else
              {
                  String message = "Username already exists";
                  request.getSession().setAttribute("alert", message);
                  getServletContext().getRequestDispatcher("/signup.jsp").forward(request, response);
              }
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
